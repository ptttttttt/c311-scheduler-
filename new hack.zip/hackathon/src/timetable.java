import java.util.Scanner;


public class timetable {
    public static void main(String args[]) {
        for (int hhh = 0; hhh >-1; hhh++) {
            Scanner read = new Scanner(System.in);
            System.out.println("do you want to initiate the time table,you have to enter in your actitvity and enter if you have completed" +
                    "it,make sure to have atleast 1 period");
            String qwwq = read.nextLine();
            if (qwwq.equals("yes")) {
                int task_count = 0;
                int c = 0;
                int i = 0;

                System.out.println("how many time tables do you want");
                int number_of_time_tables = read.nextInt();
                System.out.println("how many hours of the day do you want to create your schedule for");
                int hours = read.nextInt();
                try {
                    String[][] time_tables = new String[number_of_time_tables][hours];
                    int time_table_points = 0;

                    for (i = 0; i < number_of_time_tables; i++) {

                        for (int j = 0; j < hours; j++) {
                            if (i == 0) {
                                time_tables[i][i + 1] = read.nextLine();
                                System.out.println(" enter name of the task");
                                task_count += 1;
                            } else {
                                time_tables[i][i - 1] = read.nextLine();
                                System.out.println(" enter name of the task");
                                task_count += 1;
                            }

                        }
                        for (int w = 0; w < hours; w++) {
                            if (i == 0) {
                                String z = read.nextLine();

                                System.out.println("have you finished " + time_tables[i][i + 1] + "?");
                                if (z.equals("yes")) {
                                    c = c + 1;
                                }
                            } else {
                                String z = read.nextLine();

                                System.out.println("have you finished " + time_tables[i][i-1 ] + "?");
                                if (z.equals("yes")) {
                                    c = c + 1;
                                }
                            }


                        }


                    }

                    System.out.println("you have completed " + c + "tasks out of " + task_count);
                } catch (Exception e) {
                    System.out.println("You must have a schedule of more than 1 hour");

                }
                double bruh = (c / task_count) * 100;

                if (bruh == 100) {
                    System.out.println("very good,all activites scheduled is completes");
                } else if (bruh >= 80) {
                    System.out.println("good but some of activites were not completed ");

                } else if (bruh >= 50) {
                    System.out.println("bad you are missing several activities");
                } else if (bruh >= 30) {
                    System.out.println("very bad you are missing most of you actitvities");
                } else {
                    System.out.println("status:severe,GET TO WORK!!!!!!!");
                }
            } else {
                  System.out.println("ok,return when you need to use");
            }
        }
    }
}



