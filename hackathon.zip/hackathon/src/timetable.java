import java.util.Scanner;


public class timetable {
    public static void main(String args[]) {
        int c = 0;
        int i = 0;
        Scanner read = new Scanner(System.in);
        System.out.println("how many time tables do you want");
        int number_of_time_tables = read.nextInt();
        System.out.println("how many hours of the day do you want to create your schedule for");
        int hours = read.nextInt();
        String[][] time_tables = new String[number_of_time_tables][hours];
        int time_table_points = 0;
        int task_count = 0;
        for (i = 0; i < number_of_time_tables; i++) {

            for (int j = 0; j < hours; j++) {
                if (i == 0) {
                    time_tables[i][i + 1] = read.nextLine();
                    System.out.println(" enter name of the task");
                    task_count+=1;
                } else {
                    time_tables[i][i-1] = read.nextLine();
                    System.out.println(" enter name of the task");
                    task_count+=1;
                }

            }
            for (int w = 0; w < hours; w++) {
                if (i == 0) {
                    String z = read.nextLine();

                    System.out.println("have you finished " + time_tables[i][i + 1] + "?");
                    if (z.equals("yes")) {
                        c = c + 1;
                    }
                } else {
                    String z = read.nextLine();

                    System.out.println("have you finished " + time_tables[i][i-1] + "?");
                    if (z.equals("yes")) {
                        c = c + 1;
                    }
                }



            }



        }

    System.out.println("you have completed "+c+"tasks out of "+task_count);

    }

}



