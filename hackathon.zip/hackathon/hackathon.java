/* psuedocode
create a 2dimensional array with index

 */




import java.util.Scanner;
public class hackathon {
    public static void main (String args[]) {
        Scanner read = new Scanner(System.in);
        System.out.println("how many time tables do you want");
        int number_of_time_tables = read.nextInt();
        System.out.println("how many hours of the day do you want to create your schedule for");
        int hours = read.nextInt();
        for (int i = 0; i < number_of_time_tables; i++) {
            for (int j = 0; j < hours; j++) {
                System.out.println(" enter name of the task");
                time_table[i][j]  = read.nextLine;
                System.out.println(" enter the number of points for the task");
                time_table_points[] [] = read.nextInt();
            }
        }

    }
    private static int sumArrays(int[] [] time_table_points) {
        for (int i = 0; i < number_of_time_tables; i++) {
            for (int j = 0; j < hours; j++) {
                time_table[i][j]  = read.nextLine;
                System.out.println(" enter the number of points for the task");
                time_table_points[] [] = read.nextInt();
            }
        }
    }


    }



